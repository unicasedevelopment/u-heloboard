<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pengajuan_Dana extends Model
{
    use HasFactory;
    protected $table = 'pengajuan_dana';
    protected $fillable = [
        'tgl_pengajuan',
        'id_kategori',
        'id_creator',
        'id_divisi',
        'status_approval_1',
        'status_approval_2',
        'keperluan',
        'status_pangajuan',
        'status_pemrosesan'
    ];
}