<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Jenis_Surat;
use App\Models\Surat_Keluar;
use App\Models\Divisi;
use App\Models\Kategori_Dana;
use App\Models\Metode_Pembayaran;
use App\Models\Jenis_Pajak;
use App\Models\Pengajuan_Dana;
use App\Models\Informasi_Pembayaran;
use App\Models\Informasi_Perpajakan;

class Pengajuan_Dana_Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $jenis_pajak = Jenis_Pajak::get();
        $data_kategori = Kategori_Dana::get();
        $data_kategori_dana = Kategori_Dana::pluck('nama_kategori','id');
        $data_jenis_surat = Jenis_Surat::pluck('nama_jenis','id');
        $data_divisi = Divisi::pluck('nama_divisi','id');
        $metode_pembayaran = Metode_Pembayaran::pluck('nama_metode','id');

        return view('pengajuan_dana.index',compact('data_jenis_surat','data_divisi','data_kategori_dana','data_kategori','metode_pembayaran','jenis_pajak'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $nama_lampiran = $request->post('nama_lampiran');
        $file_lampiran = $request->file('file_lampiran');

        $validate_data['tgl_pengajuan'] = $request->post('tgl_pengajuan');
        $validate_data['id_creator'] = '1';
        $validate_data['id_divisi'] = '1';
        $validate_data['id_kategori'] = $request->post('id_kategori');
        $validate_data['status_approval_1'] = 'no';
        $validate_data['status_approval_2'] = 'no';
        $validate_data['keperluan'] = $request->post('keperluan');
        $validate_data['status_pangajuan'] = 'submited';
        $validate_data['status_pemrosesan'] = 'unpaid';


        $pengajuan_dana = Pengajuan_Dana::create($validate_data);


        $informasi_pembayaran = (array) json_decode($request->post('data_pembayaran'),true);

        $informasi_pembayaran["id_pengajuan"] = $pengajuan_dana->id;

        $pembayaran = Informasi_Pembayaran::create($informasi_pembayaran);

        $informasi_perpajakan = (array) json_decode($request->post('data_pajak'),true);
        for($i = 0 ; $i < count($informasi_perpajakan) ; $i++){
            $informasi_perpajakan[$i]["id_pengajuan"] = $pengajuan_dana->id;
            Informasi_Perpajakan::create($informasi_perpajakan[$i]);
        }



        // $validate_data['informasi_perpajakan'] = json_decode($request->post('data_pajak'));
        // $validate_data['informasi_kelengkapan'] =
        //     [
        //         "npwp" => ($request->post('npwp') != '' ? $request->post('npwp') : null ),
        //         "nik" => ($request->post('nik') != '' ? $request->post('nik') : null ),
        //         "file_invoice" => ($request->file('file_invoice') != null ? $request->file('file_invoice')->store('post-data') : null ),
        //         "file_npwp" => ($request->file('file_npwp') != null ? $request->file('file_npwp')->store('post-data') : null ),
        //         "file_ktp" => ($request->file('file_ktp') != null ? $request->file('file_ktp')->store('post-data') : null )
        //     ];

        // $validate_data['informasi_lampiran'] = [];

        // if($request->post('nama_lampiran')){
        //     for($i = 0 ; $i < count($file_lampiran) ; $i++ ){
        //         $validate_data['informasi_lampiran'][$i]=
        //         [
        //             "nama_lampiran" => $nama_lampiran[$i],
        //             "file_lampiran" => $file_lampiran[$i]->store('post-data')
        //         ];
        //     }
        // }

        // $validate_data['informasi_kelengkapan'] =
        //     [
        //         "npwp" => ($request->post('npwp') != null ? $request->post('npwp') : null ),
        //         "nik" => ($request->post('nik') != null ? $request->post('nik') : null ),
        //         "file_invoice" => ($request->file('file_invoice') != null ? $request->file('file_invoice')->store('post-data') : null ),
        //         "file_npwp" => ($request->file('file_npwp') != null ? $request->file('file_npwp')->store('post-data') : null ),
        //         "file_ktp" => ($request->file('file_ktp') != null ? $request->file('file_ktp')->store('post-data') : null )
        //     ];







        return response()->json([
            'data' => $validate_data,
            'informasi_pembayaran' => $informasi_pembayaran,
            'informasi_perpajakan' => $informasi_perpajakan,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}