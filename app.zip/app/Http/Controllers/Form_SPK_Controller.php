<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\SPK;

class Form_SPK_Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $cek = SPK::count();
        $no_surat ='';
        if($cek<1){
            $no_surat = 'FPK-GA/'.date("Y/m/d").'/'.str_pad(1,3,'0',STR_PAD_LEFT);
        }
        else{
            $nomor = SPK::all()->last();
            $urut = (int)substr($nomor->no_spk,-3);
            $no_surat = 'FPK-GA/'.date("Y/m/d").'/'.str_pad($urut+1,3,'0',STR_PAD_LEFT);
        }


        return view('form_spk.index',compact('no_surat'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $cek = SPK::count();
        $no_surat ='';
        if($cek<1){
            $no_surat = 'FPK-GA/'.date("Y/m/d").'/'.str_pad(1,3,'0',STR_PAD_LEFT);
        }
        else{
            $nomor = SPK::all()->last();
            $urut = (int)substr($nomor->no_spk,-3);
            $no_surat = 'FPK-GA/'.date("Y/m/d").'/'.str_pad($urut+1,3,'0',STR_PAD_LEFT);
        }

        return response()->json([
            'no_fpk' => $no_surat
        ]);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        // ddd($request);
        $name = $request->post('jenis_pekerjaan').'/'.$request->post('name').'/'.$request->post('divisi').'/'.$request->post('jabatan');
        $headers = array(
            'Accept' => 'application/json'
        );

        $query = array(
            'idList' => '62a95b6de5aa40089754ff41',
            'name' => $name,
            'key' => '6a708346ca5432fc510200f0b0f555c1',
            'token' => 'cd02196880c9446c6664de3374d091646ddfc5b87c5804430d149fd99dc84e2d'
        );

        $response = Http::post(
            'https://api.trello.com/1/cards',
            $query
        );


        $id = $response['id'];

        $query = array(
            'key' => '6a708346ca5432fc510200f0b0f555c1',
            'token' => 'cd02196880c9446c6664de3374d091646ddfc5b87c5804430d149fd99dc84e2d',
            'file' => $request->file()
          );

        $response = Http::post(
            'https://api.trello.com/1/cards/'.$id.'/attachments',
            $query
        );

        return $response;

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // //
        // // $cek = SPK::where('id_jenis',$id)->where('id_divisi',$request->id_divisi)->get()->last();
        // $cek = SPK::count();
        // if($cek<1){
        //     $no_surat = 'ARS-'.$divisi->kode_divisi.'-'.$jenis->kode_jenis.'-'.str_pad(1,5,'0',STR_PAD_LEFT);
        // }
        // else{
        //     // $nomor = Surat_Keluar::all()->last();
        //     $nomor = (int)substr($cek->no_arsip,-5);
        //     $no_arsip = 'ARS-'.$divisi->kode_divisi.'-'.$jenis->kode_jenis.'-'.str_pad($nomor+1,5,'0',STR_PAD_LEFT);
        // }

        // return response()->json([
        //     'no_arsip' => $no_arsip
        // ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}